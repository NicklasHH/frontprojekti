function Unilista(props) {
    
    return (
        <div>
            {
                props.unet.map(uni => {
                    return (
                        <p key={uni.id}>
                            Unenmäärä: {uni.maara}<br />
                            Päivämäärä: {uni.pvm}<br />
                            Unenlaatu: {uni.laatu}<br />
                            Lisätietoja: {uni.lisatiedot}<br />
                            <input class='buttonEdit' type='button' value='Muokkaa' />
                            <input class='buttonDelete'type='button' value='Poista' />
                        </p>
                    ) // return
                }) // map
            }
        </div>
    )
}
export default Unilista;